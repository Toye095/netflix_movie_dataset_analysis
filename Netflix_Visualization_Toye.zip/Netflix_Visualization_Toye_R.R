library(ggplot2)

# Read the CSV file
netflix_data <- read.csv("C:/Users/Dell/Downloads/netflix_data.csv")

# Create a bar plot for ratings distribution
ggplot(netflix_data, aes(x=rating)) +
  geom_bar() +
  labs(title="Ratings Distribution", x="Rating", y="Count") +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))


